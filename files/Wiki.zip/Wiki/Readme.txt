Pika näppäimet:
-control+shift+s = suorittaa haun
-control+shift+q = lisää haun syvyyttä
-control+shift+1 = vaihtaa hakutavan wikipediaan
-control+shift+2 = vaihtaa hakutavan hakemaan kaikkien sivutojen tiivisteitä

Miten käyttää:
-Numbers vaikuttaa siihen kuinka syvä haku on mitä suurempi numero sitä syvempi haku
-Modes vaikuttaa hakutapaan:
    -mode-1 hakee wikipediasta
    -mode-2 hakee sivustojen tiivisteitä

Asetukset:
-samasta tiedosto sijainnista löydät settings.json tiedoston sen sisällä on asetuksia voit 
muuttaa niiden arvoja, mutta et niiden nimiä. 
-max_depth on suurin mahdollinen syvyys, josta hakea
-depth_step on kuinka suuren hypyn yksi syyvyyden vaihto tekee