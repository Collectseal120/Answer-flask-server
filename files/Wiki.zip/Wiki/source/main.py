import requests
from bs4 import BeautifulSoup
from pystray import Icon, Menu, MenuItem
from PIL import Image
import time
import keyboard
import pyperclip
import json
import os



class Settings:
    def read(file, name):
        with open(file, 'r') as f:
            config = json.load(f)

        return config[name]
   

    def write(file, name, content):
        with open(file, 'r') as f:
            config = json.load(f)
            
        config[name] = content

        #write it back to the file
        with open(file, 'w') as f:
            json.dump(config, f)



def google_custom_search(query):
    api_key = 'AIzaSyD8lW6mlgw60TMqKGCCijEC9XH2S61JUWg';
    cx = '8668cfe004b784345';

    url = 'https://www.googleapis.com/customsearch/v1'
    params = {
        'q': query,
        'key': api_key,
        'cx': cx
    }

    response = requests.get(url, params=params)

    if response.status_code == 200:
        data = response.json()
        return data
    else:
        print(f"Error: {response.status_code}")
        return None

def SearchFromWiki(query, depth=1):
    print(f"query: {query}")
    print(f"depth: {depth}")
    print(f"mdoe: {mode}")
    result = google_custom_search(query)
    links = []
    snippets = []
    if result:
        #print(result.get('items', []))
        for item in result.get('items', []):
            title = item.get('title', 'No title')
            link = item.get('link', 'No link')
            snippet = item.get('snippet', "No snippet")
            snippets.append(snippet)
            if "wikipedia" in title.lower():
                links.append(link)
    text = ""
    for link in links:
        try:
            response = requests.get(link)
            soup = BeautifulSoup(response.text, 'html.parser')
            body_content = soup.find(id='bodyContent')

            # Exclude paragraphs within 'infobox nomobile'
            infobox = body_content.find('div', class_='infobox nomobile')
            if infobox:
                for paragraph in infobox.find_all('p'):
                    paragraph.decompose()

            paragraphs = body_content.find_all('p')
            if len(paragraphs) < depth:
            	depth = len(paragraphs)
            for i in range(depth):
                text += f"{paragraphs[i].get_text()}\n"
            	#print(paragraphs[i].get_text())
        except:
            print("could not work")
    if mode == 2:
        text = ""
        for i in range(depth):
            text += f"1:{snippets[i]}\n"

    if text == "":
        return "Nothing found", False
    else:
        return text, True
depth_step = Settings.read("settings.json","depth_step")
max_depth = Settings.read("settings.json","max_depth")
depth = Settings.read("settings.json","depth")
mode = Settings.read("settings.json", "mode")
def handle_number_selection(icon, item):
    global depth
    depth = int(item.text)
    Settings.write("settings.json","depth",depth)


def search():
    output = SearchFromWiki(pyperclip.paste(), depth)
    if output[1]:
        pyperclip.copy(output[0])
    print(f"output: {output}")

def mode_select(icon, item):
    Settings.write("settings.json","mode",int(item.text))
    global mode
    mode = int(item.text)
    print(mode)


def do_mode(m):
    Settings.write("settings.json","mode",m)
    global mode
    mode = m
    print(mode)
def plus_depth():
    global depth
    depth += depth_step
    if max_depth < depth:
        depth = 1
    Settings.write("settings.json","depth",depth)
    print(depth)


# Create a sub-menu with numbers ranging from 1 to 10
number_submenu_items = [MenuItem(str(i * -1 + max_depth+1), handle_number_selection) for i in range(1, max_depth+1, depth_step)]
number_submenu = Menu(*number_submenu_items)


mode_submenu_items = [MenuItem(str(i * -1 + 3), mode_select) for i in range(1, 3)]
mode_submenu = Menu(*mode_submenu_items)

# Create the main menu with a "Numbers" option and an exit option
main_menu = [
    MenuItem('Numbers', number_submenu),
    MenuItem('Modes', mode_submenu),
    MenuItem('Exit', lambda icon, item: icon.stop())
]

# Create the icon
icon = Icon("icon", Image.open(f"{os.getcwd()}\\th.jpg"), "Title", main_menu)



# Set the icon click callback for the exit option
main_menu[-1].action = lambda icon, item: icon.stop()

# Set the icon properties
icon.icon = Image.open(f"{os.getcwd()}\\th.jpg")  # Replace with the path to your icon
icon.title = "WikiSearch"
icon.menu = main_menu


keyboard.add_hotkey('ctrl+shift+s', search)

keyboard.add_hotkey('ctrl+shift+q', plus_depth)

keyboard.add_hotkey('ctrl+shift+1', lambda: do_mode(1))
keyboard.add_hotkey('ctrl+shift+2', lambda: do_mode(2))

icon.run()

